#!/bin/sh
now=$(date +"%Y%m%d%H")

DB_DRV="com.mysql.jdbc.Driver"
DB_CON="jdbc:mysql://mobig.ch71hvh7pyfc.ap-northeast-2.rds.amazonaws.com:3306/mobig;characterEncoding=utf8" 
DB_USERNAME="admin" 
DB_PASSWORD="sktngm12!" 
DB_TABLE_NAME="mvno_req_data" 
TARGET_DIR="/user/movios/mvno_req_data/${now}" 


##### sqoop Query ##### 
sqoop import \
--driver com.mysql.jdbc.Driver \
--connect jdbc:mysql://mobig.ch71hvh7pyfc.ap-northeast-2.rds.amazonaws.com:3306/mobig;characterEncoding=utf8 \
--username admin \
--password sktngm12! \
--table mvno_req_data \
--target-dir /user/movios/mvno_req_data/${now} \
#--fields-terminated-by "," \
#--query "SELECT req_id, req_dtm, table_nm1, column_nm1, item_nm1, table_nm2, column_nm2, item_nm2, table_nm3, column_nm3, item_nm3 from mvno_req_data where substr(req_dtm,1,10)= '${now}' and \$CONDITIONS" \
#--split-by req_id

#--table ${DB_TABLE_NAME} \
#--columns "req_id, req_dtm, table_nm1, column_nm1, item_nm1, table_nm2, column_nm2, item_nm2, table_nm3, column_nm3, item_nm3" \
#--where "substr(req_dtm,1,10)=${now}" \
#--delete-target-dir \

#sqoop import --driver com.mysql.jdbc.Driver --connect jdbc:mysql://localhost/employees --username root --password hadoop --table employees --target-dir /test/employees


##### sqoop Query ##### 
#sqoop import --driver "${DB_DRV}" \
#--connect "${DB_CON}" \
#--username "${DB_USERNAME}" \
#--password "${DB_PASSWORD}" \
#--target-dir "${TARGET_DIR}" \
#--query 'SELECT req_id, req_dtm, table_nm1, column_nm1, item_nm1, table_nm2, column_nm2, item_nm2, table_nm3, column_nm3, item_nm3  \
#         FROM   mvno_req_data
#         WHERE  substr(req_dtm,1,10)=${now} \
#         AND    req_st = \"REQ\"' \
#--split-by req_id
#--outdir /user/movios/src/generated \
#--bindir /user/movios/src/generated \


##### sqoop Query ##### 
#sqoop import --driver "${DB_DRV}" \
#--connect "${DB_CON}" \
#--username "${DB_USERNAME}" \
#--password "${DB_PASSWORD}" \
#--table "${DB_TABLE_NAME}" \
#--target-dir "${TARGET_DIR}" \
#--outdir /user/movios/src/generated \
#--bindir /user/movios/src/generated \



package hiveSrc;

	
	/**
	 * SAMPLE CODE : Stat - Hive
	 */
	 
	import java.io.*;
	import java.util.*;

import org.apache.log4j.Logger;

import java.sql.Connection;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
	 
	public class HiveTest {
	    private static String hiveDriverName = "org.apache.hive.jdbc.HiveDriver";
	    Connection nConn = null;
	    private Logger logger = Logger.getLogger(this.getClass());
	    
	    public static void main(String[] args) {
	            try {
	                Class.forName(hiveDriverName);
	            } catch (ClassNotFoundException e) {
	                e.printStackTrace();
	                System.exit(1);
	            }
	            HiveTest ht = new HiveTest();
	            ht.StatStart();
	    }
	 
	    public HiveTest(){
	        //
	    }
	 
	    public void StatStart() {
	        Connection nDBCon = null;
	        String szQueryStringFile = "";
	        String szQueryVarFile = "";
	        ResultSet varResult;
	        ResultSetMetaData rsmd;
	 
	        try {
	            //Hive Connection	        	
	            nDBCon = DriverManager.getConnection("jdbc:hive2://bi-hadoop-prod-4155.bi.services.us-south.bluemix.net:10000/default;ssl=true;", "movios", "movios20170517");

	            Statement szStmt = nDBCon.createStatement();
	            
	            //�ܺκ����� �޾Ƽ� sql�� ����
	            szQueryVarFile = "select TB_NM, case when CAL_TYPE = 'BD1' then 'SUM' when CAL_TYPE = 'BD2' then 'COUNT' when CAL_TYPE = 'BD3' then 'AVG' when CAL_TYPE = 'BD4' then 'MIN' when CAL_TYPE = 'BD5' then 'MAX' end cal, CLMN_INFO1, CLMN_INFO1_CTT, CLMN_INFO2, CLMN_INFO2_CTT,  CLMN_INFO3, CLMN_INFO3_CTT, CLMN_INFO4, CLMN_INFO4_CTT, CLMN_INFO5, CLMN_INFO5_CTT, DIR_LOCATION from VAR_INFO";
	            varResult = szStmt.executeQuery(szQueryVarFile);
	            rsmd = varResult.getMetaData();
	            int columnsNumber = rsmd.getColumnCount();

	            System.out.println("columnsNumber  >>>>>>>> "+columnsNumber);

	            String columnValue ="";
	            String tb_nm ="";
	            String cal_type ="";
	            String clmn_info1 ="";
	            String clmn_info1_ctt ="";
	            String clmn_info2 ="";
	            String clmn_info2_ctt ="";
	            String clmn_info3 ="";
	            String clmn_info3_ctt ="";
	            String clmn_info4 ="";
	            String clmn_info4_ctt ="";
	            String clmn_info5 ="";
	            String clmn_info5_ctt ="";
	            String dir_location ="";
	            
	            while(varResult.next()){
	            	for (int i = 1; i <= columnsNumber; i++) {
	            		 System.out.println("in while iii   >>>>>>>> "+i+"       in while columnsNumver >>>>>>> "+columnsNumber);
	                    columnValue = varResult.getString(i);
	                    System.out.println("in while columnValue   >>>>>>>> "+columnValue);
	                    if(columnValue.length()>0){
	                    	switch(i){
	                    	case 1:	                    		
	                    		tb_nm = columnValue;
	                    		System.out.println("tb_nm   >>>>>>>> "+tb_nm);
	                    		break;
	                    	case 2:
	                    		cal_type = columnValue;
	                    		break;
	                    	case 3:
	                    		clmn_info1 = columnValue;
	                    		break;
	                    	case 4:
	                    		clmn_info1_ctt = columnValue;
	                    		break;
	                    	case 5:
	                    		clmn_info2 = columnValue;
	                    		break;
	                    	case 6:
	                    		clmn_info2_ctt = columnValue;
	                    		break;
	                    	case 7:
	                    		clmn_info3 = columnValue;
	                    		break;
	                    	case 8:
	                    		clmn_info3_ctt = columnValue;
	                    		break;
	                    	case 9:
	                    		clmn_info4 = columnValue;
	                    		break;
	                    	case 10:
	                    		clmn_info4_ctt = columnValue;
	                    		break;
	                    	case 11:
	                    		clmn_info5 = columnValue;
	                    		break;
	                    	case 12:
	                    		clmn_info5_ctt = columnValue;
	                    		break;
	                    	case 13:
	                    		dir_location = columnValue;
	                    		break;
	                    	}
	                    }	                   
	            	}	//end of for	            
	            }	//end of while
	            
	            //������ ������ sql�� HDFS�� ���Ͽ� ������ ����
	            szQueryStringFile  = "INSERT OVERWRITE DIRECTORY '"+dir_location+"' row format delimited FIELDS TERMINATED BY ',' select "+clmn_info1+", "+clmn_info2+", ROUND("+cal_type+"(JIGA)) as AVG_JIGA from "+tb_nm+" group by "+clmn_info1+", "+clmn_info2+"";
//	            szQueryStringFile = "INSERT OVERWRITE DIRECTORY '/user/movios/result' row format delimited FIELDS TERMINATED BY ',' select SGG_CD as CD, SIGUNGU_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA from SEOUL_LAND_INFO group by SGG_CD, SIGUNGU_NM UNION ALL select BJDONG_CD as CD, BJDONG_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA  from SEOUL_LAND_INFO group by BJDONG_CD, BJDONG_NM";	           
	            szStmt.executeQuery(szQueryStringFile);

	            szStmt.close();
	            nDBCon.close();

	        }
	        catch(SQLException se) {
	            se.printStackTrace();
	        }
	        catch(Exception e) {
	            e.printStackTrace();
	        }
	        finally {
	            if(nDBCon != null) {
	                nDBCon = null;
	            }	            
	        }
	        return;
	    }
	}



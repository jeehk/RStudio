CREATE EXTERNAL TABLE IF NOT EXISTS SEOUL_LAND_INFO (
SIDO_NM STRING,
SIGUNGU_NM STRING,
BJDONG_NM STRING,
LAND_CD STRING,
JIGA STRING,
SGG_CD STRING,
BJDONG_CD STRING,
LAND_GBN STRING,
LAND_GBN_NM STRING,
BOBN STRING,
BUBN STRING,
YEAR STRING,
BASE_MON STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/input';


Drop TABLE IF EXISTS VAR_INFO;


--�ñ�����/���� �������� ��հ�
select SGG_CD as CD, SIGUNGU_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA 
from SEOUL_LAND_INFO 
group by SGG_CD, SIGUNGU_NM 
UNION ALL 
select BJDONG_CD as CD, BJDONG_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA  
from SEOUL_LAND_INFO 
group by BJDONG_CD, BJDONG_NM

select SGG_CD as CD, SIDO_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA from SEOUL_LAND_INFO group by SGG_CD, SIDO_NM UNION ALL select BJDONG_CD as CD, BJDONG_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA  from SEOUL_LAND_INFO group by BJDONG_CD, BJDONG_NM


--ȭ�麯���� �޴� ���̺�
CREATE EXTERNAL TABLE IF NOT EXISTS VAR_INFO (
TB_NM STRING, 
CAL_TYPE STRING,
CLMN_INFO1 STRING, 
CLMN_INFO1_CTT STRING, 
CLMN_INFO2 STRING,
CLMN_INFO2_CTT STRING,
CLMN_INFO3 STRING,
CLMN_INFO3_CTT STRING,
CLMN_INFO4 STRING,
CLMN_INFO4_CTT STRING,
CLMN_INFO5 STRING,
CLMN_INFO5_CTT STRING,
DIR_LOCATION STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/variable';


SEOUL_LAND_INFO,BD3,SGG_CD,,SIGUNGU_NM,,,,,,,,/user/movios/result
SEOUL_LAND_INFO,BD3,BJDONG_CD,,BJDONG_NM,,,,,,,,/user/movios/result



CAL_TYPE ����
BD1 : �հ�(SUM)
BD2 : ī��Ʈ
BD3 : ���
BD4 : �ּҰ�
BD5 : �ִ밪
;

select SGG_CD as CD, SIGUNGU_NM as NM, ROUND(AVG(JIGA)) as AVG_JIGA 
from SEOUL_LAND_INFO 
group by SGG_CD, SIGUNGU_NM 


with variable as
(select TB_NM, 
case when CAL_TYPE = 'BD1' then 'SUM'
when CAL_TYPE = 'BD2' then 'COUNT'
when CAL_TYPE = 'BD3' then 'AVG'
when CAL_TYPE = 'BD4' then 'MIN'
when CAL_TYPE = 'BD5' then 'MAX' end cal,
CLMN_INFO1, CLMN_INFO1_CTT, CLMN_INFO2, CLMN_INFO2_CTT, 
CLMN_INFO3, CLMN_INFO3_CTT, CLMN_INFO4, CLMN_INFO4_CTT, 
CLMN_INFO5, CLMN_INFO5_CTT, 
DIR_LOCATION
from VAR_INFO)
select 
from 
;

DROP TABLE IF EXISTS CC_DATA;
CREATE EXTERNAL TABLE IF NOT EXISTS CC_DATA (
  sv_acnt_num varchar(20),
  svc_scrb_yymm varchar(6),
  mvno_co_cd varchar(6),
  mnp_pre_co_cd varchar(3),
  scrb_gb varchar(3),
  eqp_mdl_cd varchar(4),
  cu_birth_yy int,
  eqp_mdl_nm varchar(100),
  eqp_gb varchar(2),
  main_prod_id varchar(10),
  main_prod_nm varchar(100),
  svc_term_yymm varchar(6),
  eqp_chg_scrb_yymm1 varchar(6),
  eqp_chg_scrb_yymm2 varchar(6))
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/cc_data';


DROP TABLE IF EXISTS BS_DATA;
CREATE EXTERNAL TABLE IF NOT EXISTS BS_DATA (
  sv_acnt_num varchar(20),
  inv_yymm varchar(6),  
  inv_voice_amnt int,
  inv_data_amnt int,
  inv_msg_amnt int,
  inv_etc_amnt int,
  inv_total_amnt int,
  inv_voice_use_amnt int,
  inv_data_use_amnt int,
  inv_msg_use_amnt int,
  comm_infra_user_amnt int,
  3g_use_amnt int,
  rs_use_amnt int)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/bs_data';


--������ count, sum���� �����Ѵ�. numberŸ���� sum���� ����
--ȭ�麯���� �޴� ���̺�
Drop TABLE IF EXISTS MVNO_REQ_DATA
;

CREATE EXTERNAL TABLE IF NOT EXISTS MVNO_REQ_DATA (
  req_id varchar(10),
  req_dtm varchar(14),
  start_ym varchar(6),
  end_ym varchar(6),
  table_nm1 varchar(100),
  column_nm1 varchar(100),
  item_nm1 varchar(100),
  table_nm2 varchar(100),
  column_nm2 varchar(100),
  item_nm2 varchar(100),
  table_nm3 varchar(100),
  column_nm3 varchar(100),
  item_nm3 varchar(100))
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/mvno_req_data/2017072818'
;

CREATE EXTERNAL TABLE IF NOT EXISTS MVNO_REQ_DATA (
  req_id varchar(10),
  req_dtm varchar(14),
  start_ym varchar(6),
  end_ym varchar(6),
  table_nm1 varchar(100),
  column_nm1 varchar(100),
  item_nm1 varchar(100),
  table_nm2 varchar(100),
  column_nm2 varchar(100),
  item_nm2 varchar(100),
  table_nm3 varchar(100),
  column_nm3 varchar(100),
  item_nm3 varchar(100))
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/mvno_req_data/2017071918'
;
CREATE EXTERNAL TABLE IF NOT EXISTS MVNO_REQ_DATA (
  req_id varchar(10),
  req_dtm varchar(14),
  start_ym varchar(6),
  end_ym varchar(6),
  table_nm1 varchar(100),
  column_nm1 varchar(100),
  item_nm1 varchar(100),
  table_nm2 varchar(100),
  column_nm2 varchar(100),
  item_nm2 varchar(100),
  table_nm3 varchar(100),
  column_nm3 varchar(100),
  item_nm3 varchar(100))
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/mvno_req_data/2017072718'
;

SELECT CONCAT(CONCAT('"',REQ_ID),'"'), REQ_DTM, START_YM, END_YM, TABLE_NM1,
CONCAT(CONCAT(TABLE_NM1, '.'),COLUMN_NM1) AS COLUMN_NM,
CASE WHEN LENGTH(ITEM_NM1)=0 THEN 'NA' ELSE CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(TABLE_NM1, '.'),COLUMN_NM1),'= "'),ITEM_NM1),'"') END AS ITEM_NM1,
CASE WHEN LENGTH(TABLE_NM2)=0 THEN 'NA' ELSE TABLE_NM2 END TABLE_NM2,
CASE WHEN LENGTH(COLUMN_NM2)=0 THEN 'NA' ELSE CONCAT(CONCAT(TABLE_NM2, '.'),COLUMN_NM2) END COLUMN_NM2,
CASE WHEN LENGTH(ITEM_NM2)=0 THEN 'NA' ELSE CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(TABLE_NM2, '.'),COLUMN_NM2),'= "'),ITEM_NM2),'"') END AS ITEM_NM2,
CASE WHEN LENGTH(TABLE_NM3)=0 THEN 'NA' ELSE TABLE_NM3 END TABLE_NM3,
CASE WHEN LENGTH(COLUMN_NM3)=0 THEN 'NA' ELSE CONCAT(CONCAT(TABLE_NM3, '.'),COLUMN_NM3) END COLUMN_NM3,
CASE WHEN LENGTH(ITEM_NM3)=0 THEN 'NA' ELSE CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(TABLE_NM3, '.'),COLUMN_NM3),'= "'),ITEM_NM3),'"') END AS ITEM_NM3
FROM MVNO_REQ_DATA
WHERE REQ_ID = '5'
;

--���̽��� sql
--CC, BS �� �ִ� ���
1,2017071918,201701,201703,CC_DATA,scrb_gb,MNP,BS_DATA,inv_data_amnt,,,,
4,2017071918,201701,201703,CC_DATA,scrb_gb,MNP,CC_DATA,mvno_co_cd,M00035,BS_DATA,inv_data_amnt,
5,2017071918,201701,201703,CC_DATA,scrb_gb,MNP,BS_DATA,inv_data_amnt,,BS_DATA,inv_total_amnt,

--CC��
2,2017072818,201701,201703,CC_DATA,scrb_gb,MNP,CC_DATA,mvno_co_cd,M00035,,,

--BS��
3,2017072818,201701,201703,BS_DATA,inv_total_amnt,,BS_DATA,comm_infra_user_amnt,,,,

SELECT CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(table_nm1, '.'),column_nm1),'= "'),item_nm1),'"')
FROM MVNO_REQ_DATA
;

	INSERT OVERWRITE DIRECTORY 'user/movios/mvno_rslt_data/2017071718'
	ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
	SELECT '1' REQ_ID, C.SCRB_GB, B.inv_yymm, count(1), sum(B.INV_DATA_AMNT)	
	FROM CC_DATA C
	JOIN BS_DATA B
	ON (C.SV_ACNT_NUM = B.SV_ACNT_NUM)
	WHERE B.inv_yymm between '201701' and '201703'
	AND C.SCRB_GB = 'MNP'
	GROUP BY C.SCRB_GB, B.inv_yymm
	;






---------------
CREATE EXTERNAL TABLE IF NOT EXISTS RT_DATA (
  sv_acnt_num varchar(20),
  inv_yymm varchar(6),
  inv_voice_amnt int,
  inv_data_amnt int,
  inv_msg_amnt int)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/rt_data';

Drop TABLE IF EXISTS RT_DATA;


CREATE EXTERNAL TABLE IF NOT EXISTS ST_DATA (
  sv_acnt_num varchar(20),
  stl_yymm varchar(6),
  comm_infra_use_amnt int,
  3g_use_amnt int,
  rs_use_amnt int)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/user/movios/st_data';

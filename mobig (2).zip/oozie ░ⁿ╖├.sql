--OOZIE_HOME
http://mobig02.movios.com:11000/oozie

oozie admin -sharelibupdate -oozie http://mobig02.movios.com:11000/oozie


app log ��ȸ
yarn logs -applicationId application_1502033179607_0023	-containerId container_e05_1502033179607_0016_01_000001
yarn logs -containerId container_e05_1502033179607_0016_01_000001
yarn logs -applicationId <appId> -containerId <containerId> --nodeAddress <nodeHttpAddress>
yarn logs -applicationId application_1503282332165_0018

--job ��������
oozie job -oozie http://mobig02.movios.com:11000/oozie -kill 0000000-170807002726792-oozie-oozi-W
oozie job -oozie http://mobig02.movios.com:11000/oozie -kill 0000004-170804165740127-oozie-oozi-W
oozie jobs -oozie http://mobig02.movios.com:11000/oozie -kill -filter "user=root"
oozie jobs -oozie http://mobig02.movios.com:11000/oozie -kill -filter status=RUNNING


oozie job -oozie http://mobig02.movios.com:11000/oozie -log 0000014-170807164330057-oozie-oozi-W

--������ȸ
oozie jobs -oozie http://mobig02.movios.com:11000/oozie
oozie admin -oozie http://mobig02.movios.com:11000/oozie -status

--���� ���ɾ�
--1. job id ����
oozie job -oozie http://mobig02.movios.com:11000/oozie -config /home/movios/ctrl/job.properties -submit
oozie job -oozie http://169.56.103.56:11000 -config /home/movios/ctrl/job.properties -submit
000000-170802042110572-oozie-oozi-W

--2. job ����
oozie job -oozie http://mobig02.movios.com:11000/oozie -config /home/movios/ctrl/job.properties -run
oozie job -oozie http://169.56.103.56:11000 -config /home/movios/ctrl/job.properties -run
oozie job -oozie http://mobig02.movios.com:11000 -start 000000-170802042110572-oozie-oozi-W
oozie job -oozie http://169.56.103.56:11000 -start 000000-170802042110572-oozie-oozi-W

oozie job -oozie http://bi-hadoop-prod-4118.bi.services.us-south.bluemix.net:11000/oozie -config /home/movios/ctrl/job.properties -run
oozie job -oozie http://bi-hadoop-prod-4118.bi.services.us-south.bluemix.net:11000/oozie -info 0000000-170725003105698-oozie-oozi-W

--3. �������� Coordinator ��ȸ
oozie jobs -oozie http://bi-hadoop-prod-4155.bi.services.us-south.bluemix.net:11000/oozie -jobtype coordinator
oozie jobs -oozie http://mobig02.movios.com:11000/oozie -jobtype coordinator
oozie job -oozie http://mobig02.movios.com:11000/oozie -kill 0000005-170809154914465-oozie-oozi-C


--4. �������� Coordinator ����
oozie job -oozie http://bi-hadoop-prod-4155.bi.services.us-south.bluemix.net:11000/oozie -suspend 0000007-170628003252587-oozie-oozi-C
oozie job -oozie http://bi-hadoop-prod-4155.bi.services.us-south.bluemix.net:11000/oozie -kill 0000007-170628003252587-oozie-oozi-C
oozie job -oozie http://bi-hadoop-prod-4118.bi.services.us-south.bluemix.net:11000/oozie -kill 0000001-170725003105698-oozie-oozi-W

--5. Coordinator �����
oozie job -oozie http://bi-hadoop-prod-4118.bi.services.us-south.bluemix.net:11000/oozie -rerun 0000001-170725003105698-oozie-oozi-W




Finally i find the way to solve this issue

It's beasue the yarn schedule assign cluster resource while working with oozie.

When oozie execute a workflow , oozie launcher will occupy 1 container, and then the occupation will set up the tez application for my oozie hive2 action.

But my cluster is less 40 nodes, it's a small cluster and oozie workflow task are a lot of.

This cause not enough containers can be used to complete the tez application, and oozie launcher will not release container until tez application completed, so the cluster resource lacked.

My solution is set 2 queue in yarn queue,one is the `default` queue, and another is `oozie ` only used to work for oozie launcher, and set `default` queue name to my oozie hive2 action

Thanks again for all of your replies, the inspire me




curl -i -s --user movios:movios20170517 -X POST -H "Content-Type: application/xml" -d @oozie-mrjob-config.xml https://bi-hadoop-prod-4155.bi.services.us-south.bluemix.net:8443/gateway/default/oozie/v1/jobs?action=start

<property>
	<name>hadoop.proxyuser.oozie.hosts</name>
	<value>bi-hadoop-prod-4155.bi.services.us-south.bluemix.net</value>
</property>


<property>
     <name>fs.defaultFS</name>
     <value>hdfs://localhost:9000</value>
  </property>

    <property>
     <name>hadoop.proxyuser.hadoop.hosts</name>
     <value>*</value>
     <description> Proxy User Setup for Oozie runs </description>
    </property>

  <property>
     <name>hadoop.proxyuser.hadoop.groups</name>
     <value>*</value>
     <description> Proxy Group configuration for Oozie Run 
    </description>
  </property>


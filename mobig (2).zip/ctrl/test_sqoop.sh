#!/bin/sh

SQOOP_HOME=/usr/iop/4.2.0.0/sqoop

search_dt=$(date --date="20 year ago" +"%Y%m%d")


${SQOOP_HOME}/bin/sqoop import \
--driver com.mysql.jdbc.Driver \
--connect jdbc:mysql://sl-us-south-1-portal.0.dblayer.com:15823/compose \
--username admin \
--password BKAHMJQHQQLPHCYV \
--target-dir /user/movios2/test/employees \
--fields-terminated-by "," \
--query "select T.* from employees T where T.hire_date >= '${search_dt}' and \$CONDITIONS" \
--split-by T.emp_no

#--table employees 

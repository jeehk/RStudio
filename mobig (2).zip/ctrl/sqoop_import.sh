#!/bin/sh

now=$(date +"%Y%m%d%H%M")

db_drv="com.mysql.jdbc.Driver"
db_con="jdbc:mysql://mobig.ch71hvh7pyfc.ap-northeast-2.rds.amazonaws.com:3306/mobig" 
db_username="admin" 
db_password="sktngm12!" 
db_table_name="mvno_req_data" 
target_dir="/user/movios/mvno_req_data/${now}" 

##### sqoop Query ##### 
sqoop import --driver "${db_drv}" \
--connect "${db_con}" \
--username "${db_username}" \
--password "${db_password}" \
--query "SELECT req_id, req_dtm, sta_ym, end_ym, table_nm1, column_nm1, item_nm1, table_nm2, column_nm2, item_nm2, table_nm3, column_nm3, item_nm3 FROM mvno_req_data WHERE req_st = 'REQ' AND \$CONDITIONS" \
--split-by req_id \
--fields-terminated-by "," \
--lines-terminated-by "\n"  \
--target-dir "${target_dir}" \
#--outdir /user/movios/src/generated \
#--bindir /user/movios/src/generated 

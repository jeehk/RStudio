#!/bin/sh

DB_DRV="com.mysql.jdbc.Driver"
DB_CON="jdbc:mysql://mobig.ch71hvh7pyfc.ap-northeast-2.rds.amazonaws.com:3306/mobig;characterEncoding=utf8" 
DB_USERNAME="admin" 
DB_PASSWORD="sktngm12!" 
DB_TABLE_NAME="rslt_data" 
DB_COLUMNS="COL1, COL2, COL3, COL4, COL5" 
EXPORT_DIR="/user/movios/mvno_rslt_data" 
--EXPORT_DIR2="/tmp/temp_org" 

##### sqoop Query ##### 
sqoop export \
--driver "${DB_DRV}" \
--connect "${DB_CON}" \
--username "${DB_USERNAME}" \
--password "${DB_PASSWORD}" \
--table "${DB_TABLE_NAME}" \
--columns "${DB_COLUMNS}" \
--export-dir "${EXPORT_DIR}" \
--input-fields-terminated-by "," \
--outdir /user/movios/src/generated \
--bindir /user/movios/src/generated \


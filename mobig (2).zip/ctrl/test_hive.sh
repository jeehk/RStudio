#!/bin/bash
JAVA_HOME=/usr/java/jdk1.8.0_144
export JAVA_HOME=/usr/java/jdk1.8.0_144
HADOOP_HOME=/usr/hdp/2.4.3.0-227/hadoop/
export HADOOP_HOME=/usr/hdp/2.4.3.0-227/hadoop/

java -jar /home/movios/src/lib/MobigRequest.jar